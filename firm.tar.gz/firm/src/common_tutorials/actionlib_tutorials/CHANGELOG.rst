^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package actionlib_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.10 (2016-12-12)
-------------------
* Export message_runtime to generate wiki documentation for actionlib tutorial actions

0.1.9 (2016-12-11)
------------------
* Fix the runtime error 'SyntaxError: from __future_\_ imports must occur at the beginning of the file'
* Fix on comments
* Remove roslib references that catkin doesn't need
* Pull old fibonacci python scripts from those linked on the wiki page
* Contributors: Isaac I.Y. Saito, Kei Okada, Steven Peters, Vincent Rabaud

0.1.8 (2014-11-05)
------------------
* update package maintainer.
* Use _EXPORTED_TARGETS target suffix instead of _generate_messages_cpp
* Contributors: Daniel Stonier, Esteve Fernandez
