^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtle_actionlib
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.8 (2014-11-05)
------------------
* update package maintainer.
* Use _EXPORTED_TARGETS target suffix instead of _generate_messages_cpp
* changed shape_server code to run with the hydro mversion of turtlesim ("geometry_msgs/Twist" nad cmd_vel)
* Contributors: Benjamin Brieber, Daniel Stonier, Esteve Fernandez
