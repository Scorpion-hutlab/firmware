#include <Arduino.h>
#include <Servo.h>
#ifndef MOTOR_H
#define MOTOR_H

#ifndef KINEMATICS_H
#define KINEMATICS_H
#define RPM_TO_RPS 1/60

class Scorpion
{

	public:
		enum driver {L298, CYTRON};
		struct rpm
		{
			int motor1;
            int motor2;
            int motor3;
            int motor4;
		};
		struct velocities
    {
            float linear_x;
            float linear_y;
            float angular_z;
    };

        struct pwm
    {
            int motor1;
            int motor2;
            int motor3;
            int motor4;
    };


		Scorpion(driver MOTOR_DRIVER, int motor_pin_A, int motor_pin_B, int PWM, int min_value, int max_val, int Kp, int Ki, int Kd);
    	Scorpion(int motor_max_rpm, float wheel_diameter, float wheels_x_distance, float wheels_y_distance);
		void motor_spin(int pwm);
		double PID_compute(float setpoint, float measured_value);
		void PID_updateConstants(float kp, float ki, float kd);
    	velocities getVelocities(int rpm1, int rpm2, int rpm3, int rpm4);
		rpm getRPM(float linear_x, float linear_y, float angular_z);
	private:
		int pinA_;
		int pinB_;
		int PWM_;
		driver MOTOR_DRIVER_;
		int min_value_;
		int max_value_;
		int Kp_;
		int Ki_;
		int Kd_;
		double integral_;
    	double derivative_;
    	double prev_error_;
		int max_rpm_;
		float wheels_x_distance_;
		float wheels_y_distance_;
		float pwm_res_;
		float wheel_circumference_;
		int total_wheels_;


	};



#endif
#endif
