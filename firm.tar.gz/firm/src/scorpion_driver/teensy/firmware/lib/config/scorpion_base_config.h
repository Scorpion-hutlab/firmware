#ifndef SCORPION_BASE_CONFIG_H
#define SCORPION_BASE_CONFIG_H

// OI Modes

#define OI_MODE_OFF 				  										  0
#define OI_MODE_SAFE                                1
#define OI_MODE_FULL                                2


// Delay after mode change in ms
#define OI_DELAY_MODECHANGE_MS                      20

/*
	CHARGE STATES
*/

// Charging states
#define OI_CHARGING_NO                              0
#define OI_CHARGING_CHARGING                        1
#define OI_CHARGING_WAITING                         2
#define OI_CHARGING_ERROR                           3

/*
	BASE
*/

#define SCORPION_BASE DIFFERENTIAL_DRIVE

/*
	DRIVERS
*/

// DRIVER CAN UNCOMMENT WHICH EVER DRIVER YOU PREFER
//IT CAN ONLY SUPPORT L298 AND BTS7960 TYPE MOTOR DRIVERS
#define USE_CYTRON_DRIVER
// #define USE_CYTRON_DRIVER

/*
	IMU
*/
//uncomment the IMU you're using
#define USE_GY85_IMU
// #define USE_MPU6050_IMU
// #define USE_MPU9150_IMU
// #define USE_MPU9250_IMU
// #define USE_ADAFRUIT_IMU

#define DEBUG 1

/*
	PID VALUES
*/

#define K_P 0.6 // P constant
#define K_I 0.3 // I constant
#define K_D 0.5 // D constant


/*
	ROBOT DIMENSIONS
*/

//define your robot' specs here
#define MAX_RPM 330               // motor's maximum RPM
#define COUNTS_PER_REV 1550       // wheel encoder's no of ticks per rev
#define WHEEL_DIAMETER 0.10       // wheel's diameter in meters
#define PWM_BITS 8                // PWM Resolution of the microcontroller
#define LR_WHEELS_DISTANCE 0.235  // distance between left and right wheels
#define FR_WHEELS_DISTANCE 0.30   // distance between front and rear wheels. Ignore this if

/*
ROBOT ORIENTATION
         FRONT
    MOTOR1  MOTOR2  (2WD/ACKERMANN)
    MOTOR3  MOTOR4  (4WD/MECANUM)
         BACK
*/

/// ENCODER PINS
#define MOTOR1_ENCODER_A 15
#define MOTOR1_ENCODER_B 14

#define MOTOR2_ENCODER_A 11
#define MOTOR2_ENCODER_B 12

#define MOTOR3_ENCODER_A 17
#define MOTOR3_ENCODER_B 16

#define MOTOR4_ENCODER_A 9
#define MOTOR4_ENCODER_B 10

//MOTOR PINS
/*
	L239 DRIVERS
*/
#ifdef USE_L298_DRIVER
  #define MOTOR_DRIVER L298

  #define MOTOR1_PWM 21
  #define MOTOR1_IN_A 20
  #define MOTOR1_IN_B 1

  #define MOTOR2_PWM 5
  #define MOTOR2_IN_A 8
  #define MOTOR2_IN_B 6

  #define MOTOR3_PWM 22
  #define MOTOR3_IN_A 23
  #define MOTOR3_IN_B 0

  #define MOTOR4_PWM 4
  #define MOTOR4_IN_A 2
  #define MOTOR4_IN_B 3

  #define PWM_MAX pow(2, PWM_BITS) - 1
  #define PWM_MIN -PWM_MAX
#endif
/*
	CYTRON DRIVERS
*/
#ifdef USE_CYTRON_DRIVER
  #define MOTOR_DRIVER CYTRON

  #define MOTOR1_PWM 1 
  #define MOTOR1_IN_A 21
  #define MOTOR1_IN_B 1	//DON'T TOUCH THIS! This is just a placeholder


  #define MOTOR2_PWM 8 
  #define MOTOR2_IN_A 5
  #define MOTOR2_IN_B 1 //DON'T TOUCH THIS! This is just a placeholder


  #define MOTOR3_PWM 0 
  #define MOTOR3_IN_A 22
  #define MOTOR3_IN_B 1 //DON'T TOUCH THIS! This is just a placeholder


  #define MOTOR4_PWM 2 
  #define MOTOR4_IN_A 4
  #define MOTOR4_IN_B 1 //DON'T TOUCH THIS! This is just a placeholder


  #define PWM_MAX pow(2, PWM_BITS) - 1
  #define PWM_MIN -PWM_MAX
#endif


#endif
