#ifndef SCORPION_BASE_H
#define SCORPION_BASE_H

#include <ros/ros.h>
#include <scorpion_msgs/Velocities.h>
#include <scorpion_msgs/Imu.h>
#include <tf2_ros/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <tf2/LinearMath/Quaternion.h>
#include <geometry_msgs/TransformStamped.h>

class ScorpionBase
{
public:
    ScorpionBase();
    struct imu_packet
   {
       float linear_x;
       float linear_y;
       float linear_z;
       float acc_x;
       float acc_y;
       float acc_z;
   };
    void velCallback(const scorpion_msgs::Velocities& vel);
    void imucallback(const scorpion_msgs::Imu &imu_data, imu_packet);
   // void encodercallback(const scorpion_msgs::Encoder &encoder_data);
   
private:
    ros::NodeHandle nh_;
    ros::Publisher odom_publisher_;
    ros::Subscriber velocity_subscriber_;
    tf2::Quaternion odom_quat;
    geometry_msgs::TransformStamped odom_trans;
    nav_msgs::Odometry odom;

    float steering_angle_;
    float linear_velocity_x_;
    float linear_velocity_y_;
    float angular_velocity_z_;
    ros::Time last_vel_time_;
    float vel_dt_;
    float x_pos_;
    float y_pos_;
    float heading_;
};

#endif
