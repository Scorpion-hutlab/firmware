// Auto-generated. Do not edit!

// (in-package scorpion_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Data_packet {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sensor_name = null;
      this.address = null;
      this.acknowledgement = null;
      this.Status = null;
    }
    else {
      if (initObj.hasOwnProperty('sensor_name')) {
        this.sensor_name = initObj.sensor_name
      }
      else {
        this.sensor_name = '';
      }
      if (initObj.hasOwnProperty('address')) {
        this.address = initObj.address
      }
      else {
        this.address = '';
      }
      if (initObj.hasOwnProperty('acknowledgement')) {
        this.acknowledgement = initObj.acknowledgement
      }
      else {
        this.acknowledgement = 0;
      }
      if (initObj.hasOwnProperty('Status')) {
        this.Status = initObj.Status
      }
      else {
        this.Status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Data_packet
    // Serialize message field [sensor_name]
    bufferOffset = _serializer.string(obj.sensor_name, buffer, bufferOffset);
    // Serialize message field [address]
    bufferOffset = _serializer.string(obj.address, buffer, bufferOffset);
    // Serialize message field [acknowledgement]
    bufferOffset = _serializer.int32(obj.acknowledgement, buffer, bufferOffset);
    // Serialize message field [Status]
    bufferOffset = _serializer.int32(obj.Status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Data_packet
    let len;
    let data = new Data_packet(null);
    // Deserialize message field [sensor_name]
    data.sensor_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [address]
    data.address = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [acknowledgement]
    data.acknowledgement = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [Status]
    data.Status = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.sensor_name.length;
    length += object.address.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'scorpion_msgs/Data_packet';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b458b7c00f37597607e3c1b4ee0e9a30';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string sensor_name
    string address
    int32 acknowledgement
    int32 Status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Data_packet(null);
    if (msg.sensor_name !== undefined) {
      resolved.sensor_name = msg.sensor_name;
    }
    else {
      resolved.sensor_name = ''
    }

    if (msg.address !== undefined) {
      resolved.address = msg.address;
    }
    else {
      resolved.address = ''
    }

    if (msg.acknowledgement !== undefined) {
      resolved.acknowledgement = msg.acknowledgement;
    }
    else {
      resolved.acknowledgement = 0
    }

    if (msg.Status !== undefined) {
      resolved.Status = msg.Status;
    }
    else {
      resolved.Status = 0
    }

    return resolved;
    }
};

module.exports = Data_packet;
